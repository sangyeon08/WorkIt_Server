package com.jubilee.workit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkitApplicationTests {

	@Test
	void contextLoads() {
	}

}
