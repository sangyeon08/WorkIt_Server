package com.jubilee.workit.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ApplyRequest {
    private String coverLetter;
    private String phone;
    private String email;

}